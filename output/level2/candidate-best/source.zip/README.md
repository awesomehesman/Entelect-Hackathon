# Photospheria Level 2 — candidate-best

Reproducible source bundle for the Level 2 submission.

## Reproduce

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -e .
python scripts/generate_solutions.py
```

This regenerates `output/level2/candidate-best/solution.json`.

Expected `solution.json` SHA-256:

    3012317dd817a3ea62b4d87f7c6322ccbf44e6f9961b458b89a461d9d2a490e3

## What this solution is

Strategy: zoned balanced survival-window fill of the 5 guaranteed starter species.

- Grid: 100x70 (Cmax=7000), 500 ticks.
- Survival window (ticks): (401, 499).
- Explicit plant actions: 1980.
- Species: the five guaranteed starter species (Grass, Rose Bush, Lavender,
  Dwarf Sunflower, Oak Tree).

Predicted leaderboard score (local simulator, assumed all-soil world; NOT the
official score):

- floor (no natural spread): 111,712,520
- with natural spread:       304,625,112

The scoring model (alpha=1, k=1) is calibrated to reproduce the official
Level 1 evaluation log to full float precision. The submitted `solution.json`
is what the portal scores; this source bundle documents how it was produced.
