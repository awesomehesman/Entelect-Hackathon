# Photospheria Level 2 — candidate-best

Reproducible source bundle for the Level 2 submission.

## Reproduce

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -e .
python scripts/generate_solutions.py
```

This regenerates `output/level2/candidate-best/solution.json`.

Expected `solution.json` SHA-256:

    108436571c4cb0db5faae756d0af64dc34aa37e1e2a41efd6d255a7ba8ee216b

## What this solution is

Strategy: vertical-stripe balanced survival-window fill of the 5 guaranteed starter species (spread-containment).

- Grid: 70x100 (Cmax=7000), 500 ticks.
- Survival window (ticks): (401, 499).
- Explicit plant actions: 1980.
- Species: the five guaranteed starter species (Grass, Rose Bush, Lavender,
  Dwarf Sunflower, Oak Tree).

Predicted leaderboard score (local simulator, assumed all-soil world; NOT the
official score):

- floor (no natural spread): 111,712,520
- with natural spread:       128,681,888

The scoring model (alpha=1, k=1) is calibrated to reproduce the official
Level 1 evaluation log to full float precision. The submitted `solution.json`
is what the portal scores; this source bundle documents how it was produced.
