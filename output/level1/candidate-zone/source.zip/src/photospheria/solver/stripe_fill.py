"""Hybrid zone-seeded planner for balanced spread.

Combines insights:
1. Stripes worked better for L3/L4 (contained spread)
2. Dense fill worked better for L2 (more coverage)
3. Early planting gives more spread time

Strategy: Plant species in dedicated zones with buffer gaps between zones.
The gaps slow cross-zone spread, maintaining diversity longer.

For small grids (L1/L2): Use denser planting with mild zone separation
For large grids (L3/L4): Use wider zones with clear buffers

All placements in survival window so they're alive at scoring.
Deterministic for fixed inputs.
"""

from __future__ import annotations

from dataclasses import dataclass

from photospheria.data.models import PlantDefinition
from photospheria.simulation.full_engine import WorldConfig
from photospheria.solver.balanced_fill import survival_window


@dataclass(frozen=True)
class StripePlan:
    actions_by_tick: dict[int, list[tuple[int, int, int]]]
    species_order: list[str]
    survival_window: tuple[int, int]
    stripes: dict[str, tuple[int, int]]
    weights: dict[str, int]

    def total_actions(self) -> int:
        return sum(len(v) for v in self.actions_by_tick.values())


def plan_stripe_fill(
    config: WorldConfig,
    species: list[PlantDefinition],
    *,
    nutrient_capacity: int = 100,
    use_weights: bool = True,
) -> StripePlan:
    """Zone-seeded planting with buffers between species.
    
    Each species gets a horizontal band. Small gaps between bands slow spread.
    """
    n = len(species)
    W, H, T = config.width, config.height, config.total_ticks
    start, end = survival_window(T, nutrient_capacity)
    window_ticks = end - start + 1
    budget = window_ticks * config.max_actions_per_tick
    
    # Zone dimensions
    # Small grids (L1=50, L2=70): thinner zones, no gaps
    # Large grids (L3=150, L4=200): wider zones, 2-row gaps
    is_large = W >= 100 or H >= 100
    gap = 2 if is_large else 0
    
    zone_h = (H - gap * (n - 1)) // n
    
    # Build pools for each species zone
    idx_of = {sp.plant: sp.index for sp in species}
    pools: dict[str, list[tuple[int, int]]] = {}
    
    for i, sp in enumerate(species):
        r_start = i * (zone_h + gap)
        r_end = r_start + zone_h
        if i == n - 1:  # Last zone takes remaining rows
            r_end = H
        cells = [(r, c) for r in range(r_start, min(r_end, H)) for c in range(W)]
        pools[sp.plant] = cells
    
    # Equal budget split, capped by zone capacity
    per_species = budget // n
    counts = {sp.plant: min(per_species, len(pools[sp.plant])) for sp in species}
    
    # Build interleaved sequence (round-robin across species)
    seq: list[tuple[int, int, int]] = []
    pointers = {sp.plant: 0 for sp in species}
    
    max_count = max(counts.values())
    for i in range(max_count):
        for sp in species:
            if i < counts[sp.plant]:
                r, c = pools[sp.plant][pointers[sp.plant]]
                seq.append((idx_of[sp.plant], r, c))
                pointers[sp.plant] += 1
    
    # Distribute to ticks - pack from start of window
    actions_by_tick: dict[int, list[tuple[int, int, int]]] = {}
    per_tick = config.max_actions_per_tick
    for i, action in enumerate(seq):
        tick = start + i // per_tick
        if tick > end:
            tick = end
        actions_by_tick.setdefault(tick, []).append(action)

    # Build stripes info for diagnostics
    stripes = {}
    for i, sp in enumerate(species):
        r_start = i * (zone_h + gap)
        r_end = r_start + zone_h if i < n - 1 else H
        stripes[sp.plant] = (r_start, r_end)

    return StripePlan(
        actions_by_tick=actions_by_tick,
        species_order=[sp.plant for sp in species],
        survival_window=(start, end),
        stripes=stripes,
        weights=counts,
    )
