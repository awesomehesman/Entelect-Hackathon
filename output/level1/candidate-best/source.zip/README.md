# Photospheria Level 1 — candidate-best

Reproducible source bundle for the Level 1 submission.

## Reproduce

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -e .
python scripts/generate_solutions.py
```

This regenerates `output/level1/candidate-best/solution.json`.

Expected `solution.json` SHA-256:

    cc926b57b8e42f7e27d380f096ed5ef88696df4ee58a74b1a51038334780d800

## What this solution is

Strategy: vertical-stripe balanced survival-window fill of the 5 guaranteed starter species (spread-containment).

- Grid: 50x50 (Cmax=2500), 500 ticks.
- Survival window (ticks): (401, 499).
- Explicit plant actions: 1980.
- Species: the five guaranteed starter species (Grass, Rose Bush, Lavender,
  Dwarf Sunflower, Oak Tree).

Predicted leaderboard score (local simulator, assumed all-soil world; NOT the
official score):

- floor (no natural spread): 312,795,056
- with natural spread:       347,420,970

The scoring model (alpha=1, k=1) is calibrated to reproduce the official
Level 1 evaluation log to full float precision. The submitted `solution.json`
is what the portal scores; this source bundle documents how it was produced.
