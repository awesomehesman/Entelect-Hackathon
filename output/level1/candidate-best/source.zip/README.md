# Photospheria Level 1 — candidate-best

Reproducible source bundle for the Level 1 submission.

## Reproduce

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -e .
python scripts/generate_solutions.py
```

This regenerates `output/level1/candidate-best/solution.json`.

Expected `solution.json` SHA-256:

    eda3fec32042e98dc118f850b5379626dcc9779a1e391f4718b912aa851d5791

## What this solution is

Strategy: zoned balanced survival-window fill of the 5 guaranteed starter species.

- Grid: 50x50 (Cmax=2500), 500 ticks.
- Survival window (ticks): (401, 499).
- Explicit plant actions: 1980.
- Species: the five guaranteed starter species (Grass, Rose Bush, Lavender,
  Dwarf Sunflower, Oak Tree).

Predicted leaderboard score (local simulator, assumed all-soil world; NOT the
official score):

- floor (no natural spread): 312,795,056
- with natural spread:       376,690,788

The scoring model (alpha=1, k=1) is calibrated to reproduce the official
Level 1 evaluation log to full float precision. The submitted `solution.json`
is what the portal scores; this source bundle documents how it was produced.
