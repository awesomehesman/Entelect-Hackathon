"""Early-start balanced fill planner for maximum spread time.

Key insight: Planting at the START of survival window gives plants maximum
time to spread before final scoring. More spread = more coverage = more
animal spawns = potential unlock cascades.

Strategy:
- Plant all actions as EARLY as possible in the survival window
- Equal distribution of all 5 starters for diversity
- Spread across entire grid to maximize geographic coverage

All placements still within survival window so manually-placed cells survive.
Deterministic for fixed inputs.
"""

from __future__ import annotations

from dataclasses import dataclass

from photospheria.data.models import PlantDefinition
from photospheria.simulation.full_engine import WorldConfig
from photospheria.solver.balanced_fill import survival_window


@dataclass(frozen=True)
class StripePlan:
    actions_by_tick: dict[int, list[tuple[int, int, int]]]
    species_order: list[str]
    survival_window: tuple[int, int]
    stripes: dict[str, tuple[int, int]]
    weights: dict[str, int]

    def total_actions(self) -> int:
        return sum(len(v) for v in self.actions_by_tick.values())


def plan_stripe_fill(
    config: WorldConfig,
    species: list[PlantDefinition],
    *,
    nutrient_capacity: int = 100,
    use_weights: bool = True,
) -> StripePlan:
    """Plant at START of survival window for maximum spread time.
    
    Uses entire budget but concentrates actions early for spread.
    """
    n = len(species)
    W, H, T = config.width, config.height, config.total_ticks
    start, end = survival_window(T, nutrient_capacity)
    window_ticks = end - start + 1
    budget = window_ticks * config.max_actions_per_tick
    
    # All cells - use a SPREAD pattern (not row-major) for geographic diversity
    # Checkerboard-ish: skip cells to spread plants across the grid
    all_cells = []
    step = max(1, (W * H) // budget)  # spread across grid
    for idx in range(0, W * H, max(1, step)):
        r, c = idx // W, idx % W
        all_cells.append((r, c))
    
    # Fill remaining with sequential cells if budget allows more
    if len(all_cells) < budget:
        used = set(all_cells)
        for r in range(H):
            for c in range(W):
                if (r, c) not in used and len(all_cells) < budget:
                    all_cells.append((r, c))
    
    # Equal distribution
    per_species = min(budget // n, len(all_cells) // n)
    counts = {sp.plant: per_species for sp in species}
    
    # Use any remaining budget
    remaining = min(budget, len(all_cells)) - (per_species * n)
    for sp in species:
        if remaining <= 0:
            break
        counts[sp.plant] += 1
        remaining -= 1
    
    # Build interleaved sequence (round-robin)
    idx_of = {sp.plant: sp.index for sp in species}
    seq: list[tuple[int, int, int]] = []
    
    cell_idx = 0
    max_per = max(counts.values())
    for i in range(max_per):
        for sp in species:
            if i < counts[sp.plant] and cell_idx < len(all_cells):
                r, c = all_cells[cell_idx]
                seq.append((idx_of[sp.plant], r, c))
                cell_idx += 1
    
    # Distribute to ticks - PACK EARLY (fill each tick to 20 before moving on)
    actions_by_tick: dict[int, list[tuple[int, int, int]]] = {}
    per_tick = config.max_actions_per_tick
    for i, action in enumerate(seq):
        tick = start + i // per_tick  # Start from beginning of window
        if tick > end:
            tick = end  # Cap at window end
        actions_by_tick.setdefault(tick, []).append(action)

    return StripePlan(
        actions_by_tick=actions_by_tick,
        species_order=[sp.plant for sp in species],
        survival_window=(start, end),
        stripes={},
        weights=counts,
    )
