# Photospheria Level 3 — candidate-best

Reproducible source bundle for the Level 3 submission.

## Reproduce

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -e .
python scripts/generate_solutions.py
```

This regenerates `output/level3/candidate-best/solution.json`.

Expected `solution.json` SHA-256:

    cb9e47b2fa93010e02bf528e266dbc9b0b55c1ceda6ed669b4f4d01e104686bb

## What this solution is

Strategy: zoned balanced survival-window fill of the 5 guaranteed starter species.

- Grid: 150x150 (Cmax=22500), 800 ticks.
- Survival window (ticks): (701, 799).
- Explicit plant actions: 1980.
- Species: the five guaranteed starter species (Grass, Rose Bush, Lavender,
  Dwarf Sunflower, Oak Tree).

Predicted leaderboard score (local simulator, assumed all-soil world; NOT the
official score):

- floor (no natural spread): 34,095,006
- with natural spread:       136,830,826

The scoring model (alpha=1, k=1) is calibrated to reproduce the official
Level 1 evaluation log to full float precision. The submitted `solution.json`
is what the portal scores; this source bundle documents how it was produced.
