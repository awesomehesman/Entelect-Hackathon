# Photospheria Level 4 — candidate-best

Reproducible source bundle for the Level 4 submission.

## Reproduce

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install -e .
python scripts/generate_solutions.py
```

This regenerates `output/level4/candidate-best/solution.json`.

Expected `solution.json` SHA-256:

    98c19dae17f7d4ae0eb53b57bc60aff53cb96a9b71f954546d65f34456b306e0

## What this solution is

Strategy: vertical-stripe balanced survival-window fill of the 5 guaranteed starter species (spread-containment).

- Grid: 200x300 (Cmax=60000), 800 ticks.
- Survival window (ticks): (701, 799).
- Explicit plant actions: 1980.
- Species: the five guaranteed starter species (Grass, Rose Bush, Lavender,
  Dwarf Sunflower, Oak Tree).

Predicted leaderboard score (local simulator, assumed all-soil world; NOT the
official score):

- floor (no natural spread): 8,856,105
- with natural spread:       29,049,194

The scoring model (alpha=1, k=1) is calibrated to reproduce the official
Level 1 evaluation log to full float precision. The submitted `solution.json`
is what the portal scores; this source bundle documents how it was produced.
